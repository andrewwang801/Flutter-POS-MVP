import 'package:flutter_test/flutter_test.dart';
import 'package:esc_pos_printer/esc_pos_printer.dart';

void main() {
  test('Tests not implemented', () {
    expect(1, 1);
  });
}
